# infopedia
 Welcome to Infopedia, the innovative content sharing website that focuses on agriculture,
technology, and healthcare. Our platform is designed to provide you with comprehensive and
up-to-date information in these essential fields. Whether you're a farmer, a tech enthusiast, or
someone interested in healthcare, Infopedia is your go-to resource for knowledge and insights.
Join us on this journey of discovery and empowerment as we explore the latest advancements
and best practices in agriculture, technology, and healthcare. Together, let's unlock the potential
of these sectors and make a positive impact in our world.

Admin login 
-username-veeresh
-password-123
